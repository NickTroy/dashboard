$(document).ready(function(){
  alert('chat');	
  $('#rstab').hide();
})
;
