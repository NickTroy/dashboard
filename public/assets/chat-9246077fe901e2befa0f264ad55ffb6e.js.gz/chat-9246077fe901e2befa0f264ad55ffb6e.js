$(document).on('page:load', function(){
  $('#rstab').hide();
  alert('chat');
});  

$(document).ready(function(){
  $('#rstab').hide();
  alert('chat');
});  
